# France-IOI solutions

These are my solutions, written in Python, to several algorithmic problems found on [France-IOI](http://www.france-ioi.org).

I will update the repo while I progress through the levels.