phrase=input()
print(phrase.upper())
