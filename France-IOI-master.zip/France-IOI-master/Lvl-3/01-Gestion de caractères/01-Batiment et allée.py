nomAuteur=input()
ageAuteur=int(input())

batiment=ord(nomAuteur[0])-64
allee=chr(ageAuteur+64)

print("{}{}".format(nomAChiffre, ageALettre))
