numIngrédients=int(input())
listeIngrédients=[500,180,650,25,666,42,421,1,370,211]

print(listeIngrédients[numIngrédients])
