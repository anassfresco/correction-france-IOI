nbLignes=int(input())

for numLigne in range(nbLignes) :
   texte=input()
   if numLigne%2==0 :
      print(texte)
