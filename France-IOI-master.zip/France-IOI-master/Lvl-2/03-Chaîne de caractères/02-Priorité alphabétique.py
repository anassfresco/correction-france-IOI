nom1=input()
nom2=input()

if nom1<nom2 :
   print(nom1)
elif nom1>nom2 :
   print(nom2)
