nom=input()

if nom[0]<="F" :
   print(1)
elif nom[0]<="P" :
   print(2)
else :
   print(3)
