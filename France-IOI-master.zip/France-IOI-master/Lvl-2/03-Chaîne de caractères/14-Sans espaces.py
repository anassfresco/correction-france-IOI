texte=list(input())

for loop in range(len(texte)) :
   if texte[loop]==" " :
      texte[loop]="_"
 
print("".join(texte))
