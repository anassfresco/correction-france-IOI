titre=input()
longueur=len(titre)

for loop in range(longueur) :
   print(titre[loop])
