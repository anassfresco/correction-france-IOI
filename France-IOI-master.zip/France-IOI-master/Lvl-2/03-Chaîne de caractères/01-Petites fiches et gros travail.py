for loop in range(6) :
   titre=input()
   auteur=input()
   print(auteur)
   print(titre)
