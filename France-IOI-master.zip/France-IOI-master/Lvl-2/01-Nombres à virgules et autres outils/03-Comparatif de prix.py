nbLegumes=int(input())

for loop in range(nbLegumes) :
   poids=float(input())
   age=float(input())
   prix=float(input())
   prixKg=prix/poids
   print(prixKg)
