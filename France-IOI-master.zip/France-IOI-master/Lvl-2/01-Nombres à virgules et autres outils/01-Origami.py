epaisseur=0.011

for loop in range(15) :
   epaisseur*=2
   
print(epaisseur)
