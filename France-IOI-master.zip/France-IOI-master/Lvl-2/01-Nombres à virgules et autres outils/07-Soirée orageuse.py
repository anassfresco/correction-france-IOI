from math import *

secondes=float(input())
vitesse=0.34029

distance=round(secondes*vitesse)

print(distance)
