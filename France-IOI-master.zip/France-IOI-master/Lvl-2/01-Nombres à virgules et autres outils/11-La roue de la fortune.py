nbZones = int(input())
print(nbZones % 24)
