lieues=float(input())
km=lieues/0.707
print(km)
