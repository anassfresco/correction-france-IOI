from math import *

cimentNécessaire=float(input())
sac=60
prix=45

prixTotal=prix*ceil(cimentNécessaire/sac)

print(prixTotal)
