argentDispo=int(input())
prix=int(input())

nbLivres=argentDispo//prix

print(nbLivres)
