nbPersonnes=int(input())
nbFruits=int(input())

if nbFruits%nbPersonnes==0 :
   print("oui")
else :
   print("non")
