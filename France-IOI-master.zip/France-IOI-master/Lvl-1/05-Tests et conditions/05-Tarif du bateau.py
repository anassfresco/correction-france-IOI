age=int(input())

if (age<21) :
   print("Tarif réduit")
else :
   print("Tarif plein")
