borneDepart=int(input())
borneArrivee=int(input())

total=borneArrivee-borneDepart

if total<0 :
   total=-total

print(total)
