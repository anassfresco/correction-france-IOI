code=int(input())

if code==64741 :
   print("Bon festin !")
else :
   print("Allez-vous en !")
