nbBagages=int(input())
poidsBagages=int(input())
poidsTotal=nbBagages*poidsBagages

if(poidsTotal>105) :
   print("Surcharge !")
