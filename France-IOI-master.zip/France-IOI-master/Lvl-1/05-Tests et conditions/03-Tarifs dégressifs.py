heureArrivee=int(input())
prix=10+5*heureArrivee

if(prix>53) :
   print(53)
else :
   print(prix)
