déUn=int(input())
déDeux=int(input())

if ((déUn+déDeux)>=10) :
   print("Taxe spéciale !")
   print(36)
else :
   print("Taxe régulière")
   print((déUn+déDeux)*2)
