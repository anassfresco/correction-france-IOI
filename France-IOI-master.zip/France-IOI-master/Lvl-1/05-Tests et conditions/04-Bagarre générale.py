supArignon=int(input())
supEvaran=int(input())

if supArignon-supEvaran>10 :
   print("La famille Arignon a un champ trop grand")
   
if supEvaran-supArignon>10 :
   print("La famille Evaran a un champ trop grand")
