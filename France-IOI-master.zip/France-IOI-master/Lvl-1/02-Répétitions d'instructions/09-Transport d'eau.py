from robot import *

for loop in range(2) :
   gauche()
   
print("Bonjour, laissez-moi vous aider")

ramasser()

for loop in range(32) :
   droite()
   
deposer()
