from robot import *

for loop in range(15) :
   droite()
   ramasser()
   
droite()
deposer()
