for loop in range(20) :
   for loop in range(20) :
      print("O",end="")
      print("X",end="")
   print()
   for loop in range(20) :
      print("X",end="")
      print("O",end="")
   print()
