totalBetes=0

for loop in range(20) :
   nbBetes=int(input())
   totalBetes+=nbBetes
print(totalBetes)
