nbNombres=int(input())
nbDepart=66
nbIncrement=1

for loop in range(nbNombres) :
   print(nbDepart)
   nbIncrement+=1
   nbDepart*=nbIncrement
   
