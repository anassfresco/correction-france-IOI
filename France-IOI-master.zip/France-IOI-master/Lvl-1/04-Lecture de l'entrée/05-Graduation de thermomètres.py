tempMin=int(input())
tempMax=int(input())

for loop in range(tempMin,tempMax+1) :
   print(tempMin)
   tempMin+=1
