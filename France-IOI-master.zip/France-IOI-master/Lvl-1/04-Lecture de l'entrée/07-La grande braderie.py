positionDepart=int(input())
largeurEmplacement=int(input())
nbVendeurs=int(input())

for loop in range(nbVendeurs+1) :
   print(positionDepart)
   positionDepart+=largeurEmplacement
