nbKarvas=int(input())

for loop in range(nbKarvas) :
   poids=int(input())
   age=int(input())
   longueurCornes=int(input())
   hauteur=int(input())
   print(longueurCornes*hauteur+poids)
