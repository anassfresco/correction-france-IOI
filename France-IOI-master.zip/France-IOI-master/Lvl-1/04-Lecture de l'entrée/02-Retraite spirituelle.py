dureeRando=int(input())
print(dureeRando*57600)
