nbRecopies=int(input())

for loop in range(nbRecopies) :
   print("Je dois suivre en cours")
