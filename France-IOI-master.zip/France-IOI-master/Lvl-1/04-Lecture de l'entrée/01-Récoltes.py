longueur=int(input())
aire=longueur*longueur

print(aire*23)
