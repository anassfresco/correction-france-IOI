bonbon=1
nb=2

for loop in range(50) :
   print(bonbon)
   bonbon+=nb
   nb+=1
