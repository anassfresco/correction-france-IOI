nb=100

for loop in range(101) :
   print(nb)
   nb-=1
print("Décollage !")
