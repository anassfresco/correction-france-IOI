crapauds=1337

for loop in range(12) :
   crapauds*=2
print(crapauds)
