nb=1

for loop in range(100) :
   print(nb)
   nb+=1
print("J'arrive !")
