longueur=5*17+2*7+5+2*2

print(longueur*longueur)
print(4*longueur)
