distance=2+34+6

print(distance, end = " ")
print(distance*2, end = " ")
print(distance*3)
