population=int(input())
malades=1
jour=1

while malades<population :
   malades+=malades*2
   jour+=1
   
print(jour)
