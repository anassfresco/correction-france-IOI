totalDepenses=0
depense=0

while depense!=-1 :
   totalDepenses+=depense
   depense=int(input())
   
print(totalDepenses)
