age=int(input())
poids=int(input())

if age<10 :
   print(5)
else :
   if age!=60 :
      if poids>=20 :
         prix=30+10
      else :
         prix=30
      print(prix)
   else :
      print(0)
