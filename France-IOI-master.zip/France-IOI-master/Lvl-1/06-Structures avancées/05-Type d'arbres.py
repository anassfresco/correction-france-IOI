hauteur=int(input())
folioles=int(input())

if hauteur<=8 :
   if folioles<=5 :
      print("Falarion")
   if hauteur<=5 :
      if folioles>=8 :
         print("Tinuviel")
if hauteur>=10 :
   if folioles>=10 :
      print("Calaelen")
   if hauteur>=12 :
      if folioles<=7 :
         print("Dorthonion")
